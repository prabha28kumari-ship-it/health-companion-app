import { User, Calendar } from 'lucide-react';
import { useState } from 'react';

interface ProfileSetupScreenProps {
  onContinue: (name: string, ageRange: string) => void;
}

export function ProfileSetupScreen({ onContinue }: ProfileSetupScreenProps) {
  const [name, setName] = useState('');
  const [ageRange, setAgeRange] = useState('');

  const ageRanges = [
    '18-30 वर्ष / years',
    '31-45 वर्ष / years',
    '46-60 वर्ष / years',
    '60+ वर्ष / years'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && ageRange) {
      onContinue(name, ageRange);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-cyan-500 rounded-full mb-6">
            <User className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl mb-2">प्रोफ़ाइल सेटअप</h1>
          <p className="text-cyan-600">Profile Setup</p>
        </div>

        {/* Profile setup form */}
        <div className="bg-white rounded-3xl shadow-lg p-8">
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <p className="text-xl mb-1">अपनी जानकारी दर्ज करें</p>
              <p className="text-cyan-600 text-sm mb-6">Enter your information</p>

              {/* Name input */}
              <div className="mb-6">
                <label className="flex items-center gap-2 text-gray-700 mb-3">
                  <User className="w-4 h-4" />
                  <span>आपका नाम / Your Name</span>
                </label>
                <input
                  type="text"
                  placeholder="नाम दर्ज करें / Enter name"
                  className="w-full px-4 py-4 bg-cyan-50 border-2 border-cyan-200 rounded-xl focus:outline-none focus:border-cyan-400 transition-colors"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>

              {/* Age range selection */}
              <div className="mb-6">
                <label className="flex items-center gap-2 text-gray-700 mb-3">
                  <Calendar className="w-4 h-4" />
                  <span>आयु वर्ग / Age Range</span>
                </label>
                <div className="space-y-3">
                  {ageRanges.map((range) => (
                    <label
                      key={range}
                      className={`block p-4 border-2 rounded-xl cursor-pointer transition-all ${
                        ageRange === range
                          ? 'border-cyan-400 bg-cyan-50'
                          : 'border-cyan-200 hover:border-cyan-300'
                      }`}
                    >
                      {range}
                      <input
                        type="radio"
                        name="ageRange"
                        value={range}
                        checked={ageRange === range}
                        onChange={(e) => setAgeRange(e.target.value)}
                        className="sr-only"
                      />
                    </label>
                  ))}
                </div>
              </div>

              {/* Info box */}
              <div className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-4 mb-6">
                <p className="text-sm text-gray-700 mb-1">
                  यह जानकारी आपकी स्वास्थ्य सलाह को बेहतर बनाने में मदद करती है
                </p>
                <p className="text-sm text-cyan-600">
                  This information helps personalize your health guidance
                </p>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-cyan-500 hover:bg-cyan-600 text-white py-4 rounded-xl transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              disabled={!name || !ageRange}
            >
              पूर्ण करें / Complete Setup
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
