import { Globe, Check } from 'lucide-react';
import { useState } from 'react';

interface LanguageScreenProps {
  onContinue: (language: string) => void;
}

export function LanguageScreen({ onContinue }: LanguageScreenProps) {
  const [selectedLanguage, setSelectedLanguage] = useState('hindi');

  const languages = [
    { id: 'hindi', native: 'हिंदी', english: 'Hindi' },
    { id: 'marathi', native: 'मराठी', english: 'Marathi' },
    { id: 'bengali', native: 'बांगला', english: 'Bengali' },
    { id: 'english', native: 'English', english: 'English' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onContinue(selectedLanguage);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-cyan-500 rounded-full mb-6">
            <Globe className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl mb-2">भाषा चुनें</h1>
          <p className="text-cyan-600">Select Your Language</p>
        </div>

        {/* Language selection form */}
        <div className="bg-white rounded-3xl shadow-lg p-8 mb-6">
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <p className="text-xl mb-1">अपनी पसंदीदा भाषा चुनें</p>
              <p className="text-cyan-600 text-sm mb-6">Choose your preferred language</p>

              <div className="space-y-3">
                {languages.map((lang) => (
                  <label
                    key={lang.id}
                    className={`flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                      selectedLanguage === lang.id
                        ? 'border-cyan-400 bg-cyan-50'
                        : 'border-cyan-200 hover:border-cyan-300'
                    }`}
                  >
                    <div className="w-2 h-2 bg-gray-800 rounded-full flex-shrink-0"></div>
                    <div className="flex-1">
                      <p className="text-lg">{lang.native}</p>
                      <p className="text-cyan-600 text-sm">{lang.english}</p>
                    </div>
                    {selectedLanguage === lang.id && (
                      <Check className="w-6 h-6 text-cyan-500 flex-shrink-0" />
                    )}
                    <input
                      type="radio"
                      name="language"
                      value={lang.id}
                      checked={selectedLanguage === lang.id}
                      onChange={(e) => setSelectedLanguage(e.target.value)}
                      className="sr-only"
                    />
                  </label>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-cyan-500 hover:bg-cyan-600 text-white py-4 rounded-xl transition-colors"
            >
              आगे बढ़ें / Continue
            </button>
          </form>
        </div>

        {/* Footer note */}
        <div className="bg-cyan-50 rounded-xl p-4 text-center">
          <p className="text-sm text-gray-600">
            आप बाद में भी भाषा बदल सकते हैं
            <br />
            <span className="text-cyan-600">You can change language later from settings</span>
          </p>
        </div>
      </div>
    </div>
  );
}
