import { ArrowLeft, Settings, ShoppingBag, Phone, Info, Mic, Send, HelpCircle, X, Volume2, MessageSquare, Trash2 } from 'lucide-react';
import { useState } from 'react';

interface HealthAssistantScreenProps {
  onBack: () => void;
}

interface Message {
  id: string;
  text: string;
  timestamp: string;
  sender: 'user' | 'assistant';
}

export function HealthAssistantScreen({ onBack }: HealthAssistantScreenProps) {
  const [showSettings, setShowSettings] = useState(false);
  const [voiceInputEnabled, setVoiceInputEnabled] = useState(true);
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'नमस्ते! मैं आपकी स्वास्थ्य सहायक हूँ। मैं आपको स्वास्थ्य जानकारी और मार्गदर्शन में मदद कर सकती हूं।',
      timestamp: '07:53:34 PM',
      sender: 'assistant'
    }
  ]);
  const [inputText, setInputText] = useState('');

  const handleSendMessage = () => {
    if (inputText.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: inputText,
        timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        sender: 'user'
      };
      setMessages([...messages, newMessage]);
      setInputText('');

      // Simulate AI response
      setTimeout(() => {
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: 'मैं आपके प्रश्न को समझ रहा हूं। कृपया मुझे और जानकारी दें ताकि मैं आपकी बेहतर मदद कर सकूं।',
          timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          sender: 'assistant'
        };
        setMessages(prev => [...prev, aiResponse]);
      }, 1000);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: '1',
        text: 'नमस्ते! मैं आपकी स्वास्थ्य सहायक हूँ। मैं आपको स्वास्थ्य जानकारी और मार्गदर्शन में मदद कर सकती हूं।',
        timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        sender: 'assistant'
      }
    ]);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col relative">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="flex items-center gap-2 text-gray-700 hover:text-gray-900">
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <button onClick={() => setShowSettings(true)} className="p-2 hover:bg-gray-100 rounded-lg">
            <Settings className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-blue-100 p-3 rounded-2xl">
            <ShoppingBag className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl">स्वास्थ्य सहायक</h1>
            <p className="text-sm text-gray-600">अपने स्वास्थ्य प्रश्न पूछें</p>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto px-4 py-4 pb-24">
        {/* AI Limitations */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-4 flex gap-3">
          <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="mb-1">AI Limitations</p>
            <p className="text-sm text-gray-700">
              यह स्वास्थ्य सहायकी और मार्गदर्शन में मदद कर सकती है। यह चिकित्सा विदान या दवा सलाह नहीं दे सकती। यदि आपको स्वास्थ्य गंभीर लगता है, कृपया नजदीकी अस्पताल जाएं।
            </p>
          </div>
        </div>

        {/* Emergency */}
        <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-4 mb-4">
          <div className="flex items-start gap-3 mb-3">
            <Phone className="w-5 h-5 text-red-600 flex-shrink-0" />
            <div>
              <p className="mb-1">Emergency?</p>
              <p className="text-sm text-gray-700 mb-2">Call</p>
              <p className="text-4xl text-red-600 mb-2">108</p>
              <p className="text-sm text-red-600">immediately. Do not rely only on this app in emergencies.</p>
            </div>
          </div>
        </div>

        {/* Health Assistant Section */}
        <div className="bg-white border border-gray-200 rounded-2xl p-4 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-xl">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium">Health Assistant</p>
                <p className="text-sm text-gray-600">AI-powered guidance</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm text-green-600">Online</span>
            </div>
          </div>

          {/* Messages */}
          <div className="space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-2 ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                {message.sender === 'assistant' && (
                  <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0 h-fit">
                    <ShoppingBag className="w-4 h-4 text-blue-600" />
                  </div>
                )}
                <div className={`flex-1 ${message.sender === 'user' ? 'flex flex-col items-end' : ''}`}>
                  <div
                    className={`p-3 rounded-xl ${
                      message.sender === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-blue-50'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{message.timestamp}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Help Button */}
      <button className="fixed bottom-24 right-6 bg-gray-900 text-white p-4 rounded-full shadow-lg hover:bg-gray-800 transition-colors">
        <HelpCircle className="w-6 h-6" />
      </button>

      {/* Input Section */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3">
        <div className="flex items-center gap-2">
          <button className="p-3 hover:bg-gray-100 rounded-lg">
            <Mic className="w-5 h-5 text-gray-700" />
          </button>
          <input
            type="text"
            placeholder="प्रश्न पूछें"
            className="flex-1 px-4 py-3 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          />
          <button
            onClick={handleSendMessage}
            className="p-3 bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors"
          >
            <Send className="w-5 h-5 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden">
            {/* Modal Header */}
            <div className="bg-blue-600 text-white px-6 py-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 p-2 rounded-xl">
                  <Settings className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl">AI Assistant Settings</h2>
                  <p className="text-sm text-blue-100">सहायक सेटिंग</p>
                </div>
              </div>
              <button onClick={() => setShowSettings(false)} className="p-1 hover:bg-white/20 rounded-lg">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {/* Voice Input */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-4">
                  <Volume2 className="w-5 h-5 text-blue-600" />
                  <h3 className="font-medium">Voice Input</h3>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <p className="mb-1">वॉइस इनपुट सक्षम करें</p>
                    <p className="text-sm text-gray-600">Enable voice input</p>
                  </div>
                  <button
                    onClick={() => setVoiceInputEnabled(!voiceInputEnabled)}
                    className={`relative w-12 h-7 rounded-full transition-colors ${
                      voiceInputEnabled ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        voiceInputEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    ></div>
                  </button>
                </div>
              </div>

              {/* Chat History */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-4">
                  <MessageSquare className="w-5 h-5 text-blue-600" />
                  <h3 className="font-medium">Chat History</h3>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 flex items-center justify-between mb-3">
                  <div>
                    <p className="mb-1">स्वतः सहेजें</p>
                    <p className="text-sm text-gray-600">Auto-save conversations</p>
                  </div>
                  <button
                    onClick={() => setAutoSaveEnabled(!autoSaveEnabled)}
                    className={`relative w-12 h-7 rounded-full transition-colors ${
                      autoSaveEnabled ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        autoSaveEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    ></div>
                  </button>
                </div>

                <button
                  onClick={handleClearChat}
                  className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl transition-colors flex items-center justify-center gap-2 mb-2"
                >
                  <Trash2 className="w-5 h-5" />
                  Clear Chat History
                </button>
                <p className="text-center text-sm text-gray-600">
                  चैट इतिहास साफ करें / Delete all messages
                </p>
              </div>

              {/* About AI Assistant */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                <div className="flex items-start gap-2 mb-3">
                  <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <h3 className="font-medium text-blue-900">About AI Assistant</h3>
                </div>
                <p className="text-sm text-blue-900 mb-3">
                  This AI health assistant provides general health information and guidance. It cannot replace professional medical advice.
                </p>
                <p className="text-sm text-blue-900">
                  यह AI स्वास्थ्य सहायक सामान्य स्वास्थ्य जानकारी प्रदान करता है। यह पेशेवर चिकित्सा सलाह का विकल्प नहीं है।
                </p>
              </div>

              {/* Done Button */}
              <button
                onClick={() => setShowSettings(false)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl transition-colors"
              >
                Done / पूर्ण
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
