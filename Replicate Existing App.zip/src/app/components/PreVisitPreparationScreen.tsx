import {
  ArrowLeft,
  ClipboardCheck,
  AlertTriangle,
  FileText,
  Heart,
  Pill,
  Gift,
  PiggyBank,
  Users,
  Megaphone,
  Clock,
  Bell,
  MapPin,
  Lock,
  Info,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  Phone,
  Ambulance,
  X,
  HelpCircle
} from 'lucide-react';
import { useState } from 'react';

interface PreVisitPreparationScreenProps {
  onBack: () => void;
}

export function PreVisitPreparationScreen({ onBack }: PreVisitPreparationScreenProps) {
  const [showEmergencyNumbers, setShowEmergencyNumbers] = useState(false);
  
  // Document checklist states
  const [documentChecklist, setDocumentChecklist] = useState({
    govId: false,
    medicalReports: false,
    prescriptionSlips: false,
    labReports: false,
    insuranceCard: false,
    schemeCard: false
  });

  // Symptom preparation states
  const [symptomChecklist, setSymptomChecklist] = useState({
    symptoms: false,
    startDate: false,
    medicines: false,
    allergies: false
  });

  // Expandable sections states
  const [expandedSections, setExpandedSections] = useState<string[]>([]);

  const toggleSection = (section: string) => {
    setExpandedSections(prev =>
      prev.includes(section)
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const toggleDocument = (key: keyof typeof documentChecklist) => {
    setDocumentChecklist(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleSymptom = (key: keyof typeof symptomChecklist) => {
    setSymptomChecklist(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const documentsReady = Object.values(documentChecklist).filter(Boolean).length;
  const symptomsReady = Object.values(symptomChecklist).filter(Boolean).length;

  const safetyNotes = [
    {
      id: 'medicine',
      icon: <Pill className="w-5 h-5" />,
      iconBg: 'bg-yellow-100',
      iconColor: 'text-yellow-600',
      title: 'Medicine Safety Note',
      titleHi: 'दवा सुरक्षा नोट',
      content: [
        'Always inform your doctor about all medicines you are currently taking',
        'अपने डॉक्टर को हमेशा बताएं कि आप कौन सी दवाएं ले रहे हैं',
        'Include over-the-counter medicines, supplements, and herbal remedies',
        'Don\'t stop prescribed medicines without consulting your doctor'
      ]
    },
    {
      id: 'scheme',
      icon: <Gift className="w-5 h-5" />,
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600',
      title: 'Government Scheme Verification Note',
      titleHi: 'सरकारी योजना सत्यापन नोट',
      content: [
        'Check if you are eligible for Ayushman Bharat or state health schemes',
        'आयुष्मान भारत या राज्य स्वास्थ्य योजनाओं के लिए पात्रता जांचें',
        'Carry your scheme card to avail cashless treatment',
        'Verify with hospital if they accept your scheme before treatment'
      ]
    },
    {
      id: 'cost',
      icon: <PiggyBank className="w-5 h-5" />,
      iconBg: 'bg-pink-100',
      iconColor: 'text-pink-600',
      title: 'Cost Awareness Note',
      titleHi: 'लागत जागरूकता नोट',
      content: [
        'Ask about consultation fees and test costs beforehand',
        'परामर्श शुल्क और परीक्षण लागत पहले से पूछें',
        'Request for generic medicines to reduce costs',
        'Keep bills and receipts for insurance claims or reimbursement'
      ]
    },
    {
      id: 'caregiver',
      icon: <Users className="w-5 h-5" />,
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      title: 'Caregiver Support Note',
      titleHi: 'देखभालकर्ता सहायता नोट',
      content: [
        'Take a family member or friend with you if possible',
        'संभव हो तो परिवार के सदस्य या मित्र को साथ ले जाएं',
        'They can help remember doctor\'s advice and instructions',
        'Useful especially for elderly patients or children'
      ]
    },
    {
      id: 'communication',
      icon: <Megaphone className="w-5 h-5" />,
      iconBg: 'bg-cyan-100',
      iconColor: 'text-cyan-600',
      title: 'Communication Tip',
      titleHi: 'संचार सुझाव',
      content: [
        'Write down your questions before the visit',
        'अपॉइंटमेंट से पहले अपने सवाल लिख लें',
        'Don\'t hesitate to ask if you don\'t understand something',
        'Request explanations in your preferred language'
      ]
    },
    {
      id: 'time',
      icon: <Clock className="w-5 h-5" />,
      iconBg: 'bg-orange-100',
      iconColor: 'text-orange-600',
      title: 'Time & Queue Preparation Note',
      titleHi: 'समय और कतार तैयारी नोट',
      content: [
        'Reach 15-20 minutes before your appointment time',
        'अपॉइंटमेंट से 15-20 मिनट पहले पहुंचें',
        'Carry water and snacks if you expect long waiting times',
        'Check hospital visiting hours and OPD timings in advance'
      ]
    },
    {
      id: 'followup',
      icon: <Bell className="w-5 h-5" />,
      iconBg: 'bg-yellow-100',
      iconColor: 'text-yellow-600',
      title: 'Follow-up Reminder Note',
      titleHi: 'फॉलो-अप अनुस्मारक नोट',
      content: [
        'Ask doctor when you should come for follow-up',
        'डॉक्टर से पूछें कि फॉलो-अप कब करना है',
        'Set reminders for follow-up appointments',
        'Note down when to get test results and reports'
      ]
    },
    {
      id: 'location',
      icon: <MapPin className="w-5 h-5" />,
      iconBg: 'bg-red-100',
      iconColor: 'text-red-600',
      title: 'Location Confirmation Note',
      titleHi: 'स्थान पुष्टिकरण नोट',
      content: [
        'Confirm hospital/clinic address and directions',
        'अस्पताल/क्लिनिक का पता और दिशा की पुष्टि करें',
        'Check parking availability if traveling by vehicle',
        'Know the nearest bus stop or metro station'
      ]
    },
    {
      id: 'privacy',
      icon: <Lock className="w-5 h-5" />,
      iconBg: 'bg-gray-100',
      iconColor: 'text-gray-600',
      title: 'Privacy Note',
      titleHi: 'गोपनीयता नोट',
      content: [
        'Your medical information is confidential',
        'आपकी चिकित्सा जानकारी गोपनीय है',
        'You can request private consultation if needed',
        'Don\'t share your medical reports on social media'
      ]
    },
    {
      id: 'online',
      icon: <AlertTriangle className="w-5 h-5" />,
      iconBg: 'bg-yellow-100',
      iconColor: 'text-yellow-600',
      title: 'Online Information Warning',
      titleHi: 'ऑनलाइन जानकारी चेतावनी',
      content: [
        'Don\'t self-diagnose based on internet searches',
        'इंटरनेट खोज के आधार पर स्व-निदान न करें',
        'Always consult a qualified doctor for medical advice',
        'Online information is for awareness, not treatment'
      ]
    }
  ];

  // Emergency Numbers Modal
  const EmergencyNumbersModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-red-500 to-red-600 text-white px-6 py-4 flex items-center justify-between rounded-t-3xl">
          <div>
            <h2 className="text-xl font-bold">Emergency Numbers</h2>
            <p className="text-sm text-red-100">आपातकालीन नंबर</p>
          </div>
          <button onClick={() => setShowEmergencyNumbers(false)} className="p-1 hover:bg-red-700 rounded-lg">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          {/* 108 - Ambulance */}
          <a href="tel:108" className="block bg-red-50 border-2 border-red-500 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-full p-3">
                  <Ambulance className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-red-900">108 - Ambulance</h3>
                  <p className="text-sm text-red-700">एम्बुलेंस सेवा (24/7)</p>
                </div>
              </div>
              <Phone className="w-5 h-5 text-red-600" />
            </div>
          </a>

          {/* Hide Other Numbers - Collapsible */}
          <button
            onClick={() => toggleSection('hideNumbers')}
            className="w-full bg-gray-50 border border-gray-200 rounded-2xl p-4 flex items-center justify-center gap-2 text-gray-700 hover:bg-gray-100"
          >
            <span>Hide Other Numbers / अन्य नंबर छुपाएं</span>
            {expandedSections.includes('hideNumbers') ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {!expandedSections.includes('hideNumbers') && (
            <>
              {/* 102 - Health Helpline */}
              <a href="tel:102" className="block bg-pink-50 border border-pink-300 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-pink-100 rounded-full p-3">
                      <Heart className="w-5 h-5 text-pink-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">102 - Health Helpline</h3>
                      <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य हेल्पलाइन</p>
                    </div>
                  </div>
                  <Phone className="w-5 h-5 text-pink-600" />
                </div>
              </a>

              {/* 104 - National Health */}
              <a href="tel:104" className="block bg-blue-50 border border-blue-300 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-100 rounded-full p-3">
                      <Phone className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">104 - National Health</h3>
                      <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य पोर्टल</p>
                    </div>
                  </div>
                  <Phone className="w-5 h-5 text-blue-600" />
                </div>
              </a>

              {/* 1075 - Mother & Child */}
              <a href="tel:1075" className="block bg-pink-50 border border-pink-300 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-pink-100 rounded-full p-3">
                      <Users className="w-5 h-5 text-pink-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">1075 - Mother & Child</h3>
                      <p className="text-sm text-gray-600">गर्भावस्था व बाल देखभाल</p>
                    </div>
                  </div>
                  <Phone className="w-5 h-5 text-pink-600" />
                </div>
              </a>

              {/* 14410 - Ayushman Bharat */}
              <a href="tel:14410" className="block bg-orange-50 border border-orange-300 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-orange-100 rounded-full p-3">
                      <Gift className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">14410 - Ayushman Bharat</h3>
                      <p className="text-sm text-gray-600">आयुष्मान भारत योजना</p>
                    </div>
                  </div>
                  <Phone className="w-5 h-5 text-orange-600" />
                </div>
              </a>

              {/* 011-23978046 - Mental Health */}
              <a href="tel:01123978046" className="block bg-purple-50 border border-purple-300 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-purple-100 rounded-full p-3">
                      <Heart className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">011-23978046 - Mental Health</h3>
                      <p className="text-sm text-gray-600">मानसिक स्वास्थ्य हेल्पलाइन</p>
                    </div>
                  </div>
                  <Phone className="w-5 h-5 text-purple-600" />
                </div>
              </a>

              {/* 1800-599-0019 - COVID-19 */}
              <a href="tel:18005990019" className="block bg-green-50 border border-green-300 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-green-100 rounded-full p-3">
                      <Info className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">1800-599-0019 - COVID-19</h3>
                      <p className="text-sm text-gray-600">कोविड-19 हेल्पलाइन</p>
                    </div>
                  </div>
                  <Phone className="w-5 h-5 text-green-600" />
                </div>
              </a>

              {/* 1800-11-4995 - Poison Control */}
              <a href="tel:1800114995" className="block bg-yellow-50 border border-yellow-300 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-yellow-100 rounded-full p-3">
                      <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">1800-11-4995 - Poison Control</h3>
                      <p className="text-sm text-gray-600">विष नियंत्रण केंद्र</p>
                    </div>
                  </div>
                  <Phone className="w-5 h-5 text-yellow-600" />
                </div>
              </a>
            </>
          )}

          {/* Emergency Note */}
          <div className="bg-red-50 border-2 border-red-300 rounded-2xl p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-bold text-red-900 mb-1">Emergency Note</h3>
                <p className="text-sm text-red-800">
                  In case of life-threatening emergency, call 108 immediately. All numbers are toll-free and available 24/7.
                </p>
                <p className="text-sm text-red-800 mt-2">
                  आपातकालीन स्थिति में तुरंत 108 पर कॉल करें। सभी नंबर टोल-फ्री और 24/7 उपलब्ध हैं।
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="bg-white px-4 py-4 border-b border-gray-200">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-700 mb-4">
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
        
        <div className="flex items-start gap-3">
          <div className="bg-blue-100 rounded-2xl p-3">
            <ClipboardCheck className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">Pre-Visit Preparation Guide</h1>
            <p className="text-sm text-gray-600">Prepare before visiting doctor or hospital</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        {/* General Advisory */}
        <div className="bg-blue-50 border-2 border-blue-300 rounded-3xl p-5">
          <div className="flex items-start gap-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <h2 className="font-bold text-blue-900">🔊 General Advisory</h2>
          </div>
          <p className="text-blue-800 mb-2">
            <strong>Before visiting a doctor or hospital, please prepare the following if available.</strong>
          </p>
          <p className="text-sm text-blue-700">
            This helps save time and improves care quality.
          </p>
        </div>

        {/* Documents Checklist */}
        <div className="bg-white rounded-3xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-start gap-2">
              <div className="bg-green-100 rounded-full p-2">
                <FileText className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900">📋 Documents Checklist</h2>
                <p className="text-sm text-gray-600">Carry these documents if available</p>
              </div>
            </div>
            <span className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium">
              {documentsReady}/6 Ready
            </span>
          </div>

          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={documentChecklist.govId}
                onChange={() => toggleDocument('govId')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Government ID (Aadhaar / ID proof)</span>
              <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full font-medium">Important</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={documentChecklist.medicalReports}
                onChange={() => toggleDocument('medicalReports')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Previous medical reports</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={documentChecklist.prescriptionSlips}
                onChange={() => toggleDocument('prescriptionSlips')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Prescription slips (old & current)</span>
              <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full font-medium">Important</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={documentChecklist.labReports}
                onChange={() => toggleDocument('labReports')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Lab reports or scan results</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={documentChecklist.insuranceCard}
                onChange={() => toggleDocument('insuranceCard')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Health insurance card (if any)</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={documentChecklist.schemeCard}
                onChange={() => toggleDocument('schemeCard')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Government scheme card (Ayushman, state schemes)</span>
              <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full font-medium">Important</span>
            </label>
          </div>

          <div className="mt-4 flex items-center gap-2 text-orange-600 text-sm">
            <span>✏️</span>
            <span className="font-medium">Carry your documents if available.</span>
          </div>
        </div>

        {/* Symptom Preparation */}
        <div className="bg-white rounded-3xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-start gap-2">
              <Heart className="w-5 h-5 text-red-500 flex-shrink-0 mt-1" />
              <div>
                <h2 className="font-bold text-gray-900">📝 Symptom Preparation</h2>
                <p className="text-sm text-gray-600">Be ready to explain</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium">
                {symptomsReady}/4 Prepared
              </span>
              <button
                onClick={() => setShowEmergencyNumbers(true)}
                className="bg-gray-900 text-white p-2 rounded-full hover:bg-gray-800"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={symptomChecklist.symptoms}
                onChange={() => toggleSymptom('symptoms')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">What symptoms you are experiencing</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={symptomChecklist.startDate}
                onChange={() => toggleSymptom('startDate')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">When the symptoms started</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={symptomChecklist.medicines}
                onChange={() => toggleSymptom('medicines')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Any medicines currently taken</span>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={symptomChecklist.allergies}
                onChange={() => toggleSymptom('allergies')}
                className="w-5 h-5 accent-cyan-600"
              />
              <span className="flex-1">Any allergies or chronic conditions</span>
            </label>
          </div>
        </div>

        {/* EMERGENCY SAFETY NOTE */}
        <div className="bg-red-50 border-2 border-red-400 rounded-3xl p-5">
          <div className="flex items-start gap-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Phone className="w-4 h-4 text-red-600" />
                <h3 className="font-bold text-red-900">🚨 EMERGENCY SAFETY NOTE</h3>
              </div>
              <p className="text-red-800 mb-2">
                If symptoms are severe (unconsciousness, chest pain, heavy bleeding), do not wait — call 108 immediately.
              </p>
              <p className="text-sm italic text-red-700">
                For emergencies, call 108.
              </p>
            </div>
          </div>
        </div>

        {/* Important Safety Notes & Practical Tips */}
        <div className="bg-orange-50 rounded-3xl p-5">
          <div className="flex items-start gap-2 mb-4">
            <div className="bg-orange-100 rounded-full p-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <h2 className="font-bold text-gray-900">Important Safety Notes & Practical Tips</h2>
              <p className="text-sm text-gray-600">Essential information for your visit</p>
            </div>
          </div>

          <div className="space-y-2">
            {safetyNotes.map((note) => (
              <div key={note.id} className="bg-white rounded-2xl overflow-hidden">
                <button
                  onClick={() => toggleSection(note.id)}
                  className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`${note.iconBg} rounded-full p-2`}>
                      <span className={note.iconColor}>{note.icon}</span>
                    </div>
                    <span className="font-medium text-gray-900">{note.title}</span>
                  </div>
                  {expandedSections.includes(note.id) ? (
                    <ChevronUp className="w-5 h-5 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400" />
                  )}
                </button>
                
                {expandedSections.includes(note.id) && (
                  <div className="px-4 pb-4 pt-0">
                    <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                      {note.content.map((line, idx) => (
                        <p key={idx} className="text-sm text-gray-700">
                          • {line}
                        </p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Quick Tips Summary */}
        <div className="bg-green-50 border-2 border-green-400 rounded-3xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle className="w-6 h-6 text-green-600" />
            <h2 className="font-bold text-green-900">Quick Tips Summary</h2>
          </div>
          <div className="space-y-2">
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-green-800">Please verify at the hospital</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-green-800">Carry your documents if available</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-green-800">This is informational, not medical advice</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-green-800">Your safety comes first</p>
            </div>
          </div>
        </div>

        {/* Emergency Numbers Section */}
        <div className="bg-red-50 border-2 border-red-300 rounded-3xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Phone className="w-6 h-6 text-red-600" />
            <h2 className="font-bold text-red-900">Emergency Numbers / आपातकालीन नंबर</h2>
          </div>

          {/* 108 - Always Visible */}
          <a href="tel:108" className="block bg-red-500 text-white rounded-2xl p-4 mb-3 hover:bg-red-600 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-3">
                  <Ambulance className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">108 - Ambulance</h3>
                  <p className="text-sm text-red-100">एम्बुलेंस सेवा (24/7)</p>
                </div>
              </div>
              <Phone className="w-5 h-5 text-white" />
            </div>
          </a>

          {/* Click to Show Other Numbers */}
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleSection('emergencyNumbers');
            }}
            className="w-full bg-white border-2 border-red-300 text-red-700 py-3 rounded-2xl flex items-center justify-center gap-2 font-medium hover:bg-red-50 transition-colors"
          >
            <span>Click to {expandedSections.includes('emergencyNumbers') ? 'Hide' : 'Show'} Other Emergency Numbers (+7)</span>
            {expandedSections.includes('emergencyNumbers') ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>

          {/* Other Emergency Numbers - Collapsible */}
          {expandedSections.includes('emergencyNumbers') && (
            <div className="mt-3 space-y-2">
              {/* 102 - Health Helpline */}
              <a href="tel:102" className="block bg-pink-50 border border-pink-300 rounded-2xl p-3 hover:bg-pink-100 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-pink-100 rounded-full p-2">
                      <Heart className="w-5 h-5 text-pink-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">102 - Health Helpline</h3>
                      <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य हेल्पलाइन</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-pink-600" />
                </div>
              </a>

              {/* 104 - National Health */}
              <a href="tel:104" className="block bg-blue-50 border border-blue-300 rounded-2xl p-3 hover:bg-blue-100 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-100 rounded-full p-2">
                      <Phone className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">104 - National Health</h3>
                      <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य पोर्टल</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-blue-600" />
                </div>
              </a>

              {/* 1075 - Mother & Child */}
              <a href="tel:1075" className="block bg-pink-50 border border-pink-300 rounded-2xl p-3 hover:bg-pink-100 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-pink-100 rounded-full p-2">
                      <Users className="w-5 h-5 text-pink-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">1075 - Mother & Child</h3>
                      <p className="text-sm text-gray-600">गर्भावस्था व बाल देखभाल</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-pink-600" />
                </div>
              </a>

              {/* 14410 - Ayushman Bharat */}
              <a href="tel:14410" className="block bg-orange-50 border border-orange-300 rounded-2xl p-3 hover:bg-orange-100 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-orange-100 rounded-full p-2">
                      <Gift className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">14410 - Ayushman Bharat</h3>
                      <p className="text-sm text-gray-600">आयुष्मान भारत योजना</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-orange-600" />
                </div>
              </a>

              {/* 011-23978046 - Mental Health */}
              <a href="tel:01123978046" className="block bg-purple-50 border border-purple-300 rounded-2xl p-3 hover:bg-purple-100 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-purple-100 rounded-full p-2">
                      <Heart className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">011-23978046 - Mental Health</h3>
                      <p className="text-sm text-gray-600">मानसिक स्वास्थ्य हेल्पलाइन</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-purple-600" />
                </div>
              </a>

              {/* 1800-599-0019 - COVID-19 */}
              <a href="tel:18005990019" className="block bg-green-50 border border-green-300 rounded-2xl p-3 hover:bg-green-100 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-green-100 rounded-full p-2">
                      <Info className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">1800-599-0019 - COVID-19</h3>
                      <p className="text-sm text-gray-600">कोविड-19 हेल्पलाइन</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-green-600" />
                </div>
              </a>

              {/* 1800-11-4995 - Poison Control */}
              <a href="tel:1800114995" className="block bg-yellow-50 border border-yellow-300 rounded-2xl p-3 hover:bg-yellow-100 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-yellow-100 rounded-full p-2">
                      <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">1800-11-4995 - Poison Control</h3>
                      <p className="text-sm text-gray-600">विष नियंत्रण केंद्र</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-yellow-600" />
                </div>
              </a>
            </div>
          )}

          {/* Emergency Note */}
          <div className="bg-red-100 border border-red-300 rounded-2xl p-3 mt-3">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-red-800">
                  In case of life-threatening emergency, call 108 immediately. All numbers are toll-free.
                </p>
                <p className="text-sm text-red-800 mt-1">
                  आपातकालीन स्थिति में तुरंत 108 पर कॉल करें।
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Numbers Modal */}
      {showEmergencyNumbers && <EmergencyNumbersModal />}
    </div>
  );
}