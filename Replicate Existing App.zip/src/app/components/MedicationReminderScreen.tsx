import { ArrowLeft, Bell, Plus, Pill, Calendar, Clock, User, Phone, Trash2, AlertCircle, Users, HelpCircle, X } from 'lucide-react';
import { useState } from 'react';

interface MedicationReminderScreenProps {
  onBack: () => void;
}

type Tab = 'active' | 'today' | 'caregiver';
type ReminderType = 'medication' | 'appointment';

interface Reminder {
  id: string;
  type: ReminderType;
  title: string;
  time: string;
  frequency: string;
  instructions: string;
  doctorName: string;
  contactPhone: string;
  isActive: boolean;
  borderColor: string;
}

interface Caregiver {
  id: string;
  name: string;
  phone: string;
  relation: string;
  tags: string[];
  monitoring: string;
  isPrimary: boolean;
}

export function MedicationReminderScreen({ onBack }: MedicationReminderScreenProps) {
  const [activeTab, setActiveTab] = useState<Tab>('active');
  const [showAddReminder, setShowAddReminder] = useState(false);
  const [smsEnabled, setSmsEnabled] = useState(true);
  const [voiceCallsEnabled, setVoiceCallsEnabled] = useState(true);
  const [showAddCaregiver, setShowAddCaregiver] = useState(false);

  const reminders: Reminder[] = [
    {
      id: '1',
      type: 'medication',
      title: 'Blood Pressure Medicine',
      time: '08:00 - daily',
      frequency: 'daily',
      instructions: 'Amlodipine 5mg - Take with food',
      doctorName: 'Dr. Sharma',
      contactPhone: '+91-98765-43210',
      isActive: true,
      borderColor: 'border-l-green-500'
    },
    {
      id: '2',
      type: 'appointment',
      title: 'Cardiology Follow-up',
      time: '14:30 - monthly',
      frequency: 'monthly',
      instructions: 'Monthly check-up with Dr. Patel',
      doctorName: 'Family Member',
      contactPhone: '+91-98765-43211',
      isActive: true,
      borderColor: 'border-l-blue-500'
    }
  ];

  const todaySchedule = [
    {
      time: '07:30',
      label: 'Today',
      title: 'Diabetes Medicine',
      subtitle: 'Metformin 500mg - Before meals',
      frequency: 'twice-daily',
      icon: <Pill className="w-5 h-5" />
    },
    {
      time: '08:00',
      label: 'Today',
      title: 'Blood Pressure Medicine',
      subtitle: 'Amlodipine 5mg - Take with food',
      frequency: 'daily',
      icon: <Pill className="w-5 h-5" />
    },
    {
      time: '14:30',
      label: 'Today',
      title: 'Cardiology Follow-up',
      subtitle: 'Monthly check-up with Dr. Patel',
      frequency: 'monthly',
      icon: <Calendar className="w-5 h-5" />
    }
  ];

  const caregivers: Caregiver[] = [
    {
      id: '1',
      name: 'Dr. Sharma',
      phone: '+91-98765-43210',
      relation: 'Doctor',
      tags: ['Doctor', 'Primary'],
      monitoring: 'Blood Pressure Medicine',
      isPrimary: true
    },
    {
      id: '2',
      name: 'Priya Sharma (Daughter)',
      phone: '+91-98765-43211',
      relation: 'Family Member',
      tags: ['Family Member', 'Primary'],
      monitoring: 'All Medications',
      isPrimary: true
    },
    {
      id: '3',
      name: 'Rajesh Kumar (Son)',
      phone: '+91-98765-43212',
      relation: 'Family Member',
      tags: ['Family Member', 'Secondary'],
      monitoring: 'Emergency Situations',
      isPrimary: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-10">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-700 hover:text-gray-900 mb-4">
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Bell className="w-6 h-6 text-orange-500" />
            <div>
              <h1 className="text-2xl">Reminders</h1>
              <p className="text-sm text-gray-600">Medicine & appointment reminders</p>
            </div>
          </div>
          <button
            onClick={() => setShowAddReminder(true)}
            className="bg-gray-900 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-800 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Add Reminder
          </button>
        </div>

        {/* Safety Note */}
        <div className="bg-yellow-50 border-2 border-yellow-400 rounded-2xl p-4 mb-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-700 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-yellow-900 mb-1">Medication Reminder Safety Note</h3>
              <p className="text-sm text-yellow-800">
                Medication reminders are based on user input. Please follow the doctor's prescription strictly. This app does not recommend or change medicine dosage.
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('active')}
            className={`flex-1 py-3 rounded-lg transition-colors ${
              activeTab === 'active'
                ? 'bg-white shadow-sm border border-gray-200'
                : 'bg-transparent text-gray-600 hover:bg-gray-100'
            }`}
          >
            Active Reminders
          </button>
          <button
            onClick={() => setActiveTab('today')}
            className={`flex-1 py-3 rounded-lg transition-colors ${
              activeTab === 'today'
                ? 'bg-white shadow-sm border border-gray-200'
                : 'bg-transparent text-gray-600 hover:bg-gray-100'
            }`}
          >
            Today's Schedule
          </button>
          <button
            onClick={() => setActiveTab('caregiver')}
            className={`flex-1 py-3 rounded-lg transition-colors ${
              activeTab === 'caregiver'
                ? 'bg-white shadow-sm border border-gray-200'
                : 'bg-transparent text-gray-600 hover:bg-gray-100'
            }`}
          >
            Caregiver Alerts
          </button>
        </div>
      </header>

      {/* Main content */}
      <main className="px-4 py-4 pb-24">
        {/* Active Reminders Tab */}
        {activeTab === 'active' && (
          <div className="space-y-4">
            {reminders.map((reminder) => (
              <div
                key={reminder.id}
                className={`bg-white rounded-2xl p-4 border-l-4 ${reminder.borderColor} shadow-sm`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {reminder.type === 'medication' ? (
                      <Pill className="w-6 h-6 text-gray-700" />
                    ) : (
                      <Calendar className="w-6 h-6 text-gray-700" />
                    )}
                    <div>
                      <h3 className="font-medium mb-1">{reminder.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span>{reminder.time}</span>
                      </div>
                    </div>
                  </div>
                  <span className="bg-gray-900 text-white text-xs px-3 py-1 rounded-full">active</span>
                </div>

                <p className="text-gray-700 mb-3">{reminder.instructions}</p>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <User className="w-4 h-4" />
                    <span>{reminder.doctorName}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4" />
                    <span>{reminder.contactPhone}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-xl transition-colors">
                    Pause
                  </button>
                  <button className="bg-red-500 hover:bg-red-600 text-white p-3 rounded-xl transition-colors">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Today's Schedule Tab */}
        {activeTab === 'today' && (
          <div>
            <h2 className="text-xl mb-2">Today's Schedule</h2>
            <p className="text-sm text-gray-600 mb-6">Upcoming reminders for today</p>

            <div className="space-y-4">
              {todaySchedule.map((item, index) => (
                <div key={index} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200">
                  <div className="flex items-start gap-4">
                    <div className="text-center">
                      <div className="text-3xl font-medium mb-1">{item.time}</div>
                      <div className="text-xs text-gray-500">{item.label}</div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start gap-2 mb-2">
                        {item.icon}
                        <div className="flex-1">
                          <h3 className="font-medium mb-1">{item.title}</h3>
                          <p className="text-sm text-gray-600">{item.subtitle}</p>
                        </div>
                        <span className="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">
                          {item.frequency}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Caregiver Alerts Tab */}
        {activeTab === 'caregiver' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl mb-2">Caregiver Support</h2>
              <p className="text-sm text-gray-600 mb-4">Manage caregivers who receive alerts about your health</p>

              {/* Disclaimer */}
              <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 mb-6">
                <div className="flex items-start gap-3">
                  <Users className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-purple-900 mb-1">Caregiver Support - Disclaimer</h3>
                    <p className="text-sm text-purple-800">
                      You can add a trusted caregiver to receive alerts. Caregivers are notified about missed reminders and emergencies. This feature supports care but does not replace medical professionals.
                    </p>
                  </div>
                </div>
              </div>

              {/* SMS Notifications */}
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200 mb-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-orange-100 p-3 rounded-xl">
                      <Bell className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">SMS Notifications</h3>
                      <p className="text-sm text-gray-600">Automatic alerts when medicines are missed</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setSmsEnabled(!smsEnabled)}
                    className={`relative w-12 h-7 rounded-full transition-colors ${
                      smsEnabled ? 'bg-green-500' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        smsEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    ></div>
                  </button>
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">Missed Medicine Alert</span>
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs">Enabled</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">Daily Summary</span>
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs">Enabled</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">Appointment Reminders</span>
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs">Enabled</span>
                  </div>
                </div>

                <div className="bg-orange-50 border border-orange-200 rounded-xl p-3">
                  <p className="text-sm text-orange-900">
                    <strong>Note:</strong> SMS will be sent to all registered caregivers 15 minutes after a missed reminder.
                  </p>
                </div>
              </div>

              {/* Voice Calls */}
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-100 p-3 rounded-xl">
                      <Phone className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Voice Calls</h3>
                      <p className="text-sm text-gray-600">Emergency contact when critical meds are missed</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setVoiceCallsEnabled(!voiceCallsEnabled)}
                    className={`relative w-12 h-7 rounded-full transition-colors ${
                      voiceCallsEnabled ? 'bg-green-500' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        voiceCallsEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    ></div>
                  </button>
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">Critical Medicine Missed</span>
                    <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs">Priority</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">Emergency Situations</span>
                    <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs">Priority</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">Call Timing</span>
                    <span className="text-gray-600">After 30 min</span>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
                  <p className="text-sm text-blue-900">
                    <strong>Note:</strong> Voice calls are only made for critical medications. The first caregiver on the list will be called first.
                  </p>
                </div>
              </div>
            </div>

            {/* Registered Caregivers */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl">Registered Caregivers</h2>
                <button
                  onClick={() => setShowAddCaregiver(true)}
                  className="bg-gray-900 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-800 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  Add Caregiver
                </button>
              </div>

              <div className="space-y-4">
                {caregivers.map((caregiver) => (
                  <div key={caregiver.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start gap-3">
                        <div className="bg-gray-100 p-3 rounded-full">
                          <User className="w-5 h-5 text-gray-700" />
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">{caregiver.name}</h3>
                          <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                            <Phone className="w-4 h-4" />
                            <span>{caregiver.phone}</span>
                          </div>
                          <div className="flex gap-2 mb-2">
                            {caregiver.tags.map((tag, index) => (
                              <span
                                key={index}
                                className={`text-xs px-2 py-1 rounded ${
                                  tag === 'Doctor'
                                    ? 'bg-blue-100 text-blue-700'
                                    : tag === 'Primary'
                                    ? 'bg-orange-100 text-orange-700'
                                    : tag === 'Family Member'
                                    ? 'bg-blue-100 text-blue-700'
                                    : 'bg-gray-100 text-gray-700'
                                }`}
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                          <p className="text-sm text-gray-600">Monitoring: {caregiver.monitoring}</p>
                        </div>
                      </div>
                      <button className="text-red-500 hover:bg-red-50 p-2 rounded-lg">
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Help Button */}
      <button className="fixed bottom-6 right-6 bg-gray-900 text-white p-4 rounded-full shadow-lg hover:bg-gray-800 transition-colors">
        <HelpCircle className="w-6 h-6" />
      </button>

      {/* Add Reminder Modal */}
      {showAddReminder && (
        <AddReminderModal onClose={() => setShowAddReminder(false)} />
      )}

      {/* Add Caregiver Modal */}
      {showAddCaregiver && (
        <AddCaregiverModal onClose={() => setShowAddCaregiver(false)} />
      )}
    </div>
  );
}

interface AddReminderModalProps {
  onClose: () => void;
}

function AddReminderModal({ onClose }: AddReminderModalProps) {
  const [reminderType, setReminderType] = useState<ReminderType>('medication');
  const [medicineName, setMedicineName] = useState('');
  const [appointmentTitle, setAppointmentTitle] = useState('');
  const [time, setTime] = useState('');
  const [frequency, setFrequency] = useState('Daily');
  const [instructions, setInstructions] = useState('');
  const [doctorName, setDoctorName] = useState('');
  const [contactPhone, setContactPhone] = useState('');

  const handleSave = () => {
    // Save logic here
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between rounded-t-3xl">
          <h2 className="text-xl font-medium">Add New Reminder</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-lg">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6">
          {/* Reminder Type */}
          <div className="mb-6">
            <label className="block mb-3 font-medium">Reminder Type</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setReminderType('medication')}
                className={`py-4 rounded-xl border-2 transition-colors ${
                  reminderType === 'medication'
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <Pill className="w-6 h-6 mx-auto mb-2 text-gray-700" />
                <span className="text-gray-900">Medication</span>
              </button>
              <button
                onClick={() => setReminderType('appointment')}
                className={`py-4 rounded-xl border-2 transition-colors ${
                  reminderType === 'appointment'
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <Calendar className="w-6 h-6 mx-auto mb-2 text-gray-700" />
                <span className="text-gray-900">Appointment</span>
              </button>
            </div>
          </div>

          {/* Medicine Name OR Appointment Title */}
          {reminderType === 'medication' ? (
            <div className="mb-6">
              <label className="block mb-2 font-medium">Medicine Name</label>
              <input
                type="text"
                placeholder="e.g. Aspirin 75mg"
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                value={medicineName}
                onChange={(e) => setMedicineName(e.target.value)}
              />
            </div>
          ) : (
            <div className="mb-6">
              <label className="block mb-2 font-medium">Appointment Title</label>
              <input
                type="text"
                placeholder="e.g. Doctor Visit"
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                value={appointmentTitle}
                onChange={(e) => setAppointmentTitle(e.target.value)}
              />
            </div>
          )}

          {/* Time */}
          <div className="mb-6">
            <label className="block mb-2 font-medium">Time</label>
            <input
              type="time"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
              value={time}
              onChange={(e) => setTime(e.target.value)}
            />
          </div>

          {/* Frequency */}
          <div className="mb-6">
            <label className="block mb-2 font-medium">Frequency</label>
            <select
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'%3E%3Cpath d='M5 7.5L10 12.5L15 7.5' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 12px center'
              }}
              value={frequency}
              onChange={(e) => setFrequency(e.target.value)}
            >
              <option>Daily</option>
              <option>Twice Daily</option>
              <option>Weekly</option>
              <option>Monthly</option>
            </select>
          </div>

          {/* Instructions (only for medication) */}
          {reminderType === 'medication' && (
            <div className="mb-6">
              <label className="block mb-2 font-medium">Instructions</label>
              <textarea
                placeholder="e.g. Take with food"
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 min-h-[100px]"
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
              />
            </div>
          )}

          {/* Doctor/Contact Name */}
          <div className="mb-6">
            <label className="block mb-2 font-medium">Doctor/Contact Name</label>
            <input
              type="text"
              placeholder="e.g. Dr. Sharma"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
            />
          </div>

          {/* Contact Phone */}
          <div className="mb-6">
            <label className="block mb-2 font-medium">Contact Phone</label>
            <input
              type="tel"
              placeholder="+91-XXXXX-XXXXX"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
              value={contactPhone}
              onChange={(e) => setContactPhone(e.target.value)}
            />
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={onClose}
              className="py-3 border-2 border-gray-200 rounded-xl hover:bg-gray-50 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="py-3 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors font-medium"
            >
              Save Reminder
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface AddCaregiverModalProps {
  onClose: () => void;
}

function AddCaregiverModal({ onClose }: AddCaregiverModalProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [relationship, setRelationship] = useState('');
  const [email, setEmail] = useState('');
  const [monitoring, setMonitoring] = useState('');
  const [smsNotifications, setSmsNotifications] = useState(true);
  const [voiceCalls, setVoiceCalls] = useState(true);
  const [dailySummary, setDailySummary] = useState(false);
  const [priorityLevel, setPriorityLevel] = useState('Primary Contact (Called First)');
  const [smsDelay, setSmsDelay] = useState('After 15 minutes (Recommended)');
  const [voiceDelay, setVoiceDelay] = useState('After 30 minutes (Recommended)');

  const handleSave = () => {
    // Save logic here
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between rounded-t-3xl">
          <h2 className="text-xl font-medium">Add New Caregiver</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-lg">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6">
          {/* Caregiver Name */}
          <div className="mb-6">
            <label className="block mb-2 font-medium text-gray-900">Caregiver Name</label>
            <input
              type="text"
              placeholder="e.g. Dr. Sharma"
              className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          {/* Contact Phone */}
          <div className="mb-6">
            <label className="block mb-2 font-medium text-gray-900">Contact Phone</label>
            <input
              type="tel"
              placeholder="+91-XXXXX-XXXXX"
              className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>

          {/* Relationship */}
          <div className="mb-6">
            <label className="block mb-2 font-medium text-gray-900">Relationship</label>
            <select
              className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 appearance-none"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'%3E%3Cpath d='M5 7.5L10 12.5L15 7.5' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 12px center'
              }}
              value={relationship}
              onChange={(e) => setRelationship(e.target.value)}
            >
              <option value="">Select relationship</option>
              <option>Doctor</option>
              <option>Family Member - Spouse</option>
              <option>Family Member - Son</option>
              <option>Family Member - Daughter</option>
              <option>Family Member - Parent</option>
              <option>Friend</option>
              <option>Nurse</option>
              <option>Other</option>
            </select>
          </div>

          {/* Email Address (Optional) */}
          <div className="mb-6">
            <label className="block mb-2 font-medium text-gray-900">Email Address (Optional)</label>
            <input
              type="email"
              placeholder="caregiver@example.com"
              className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          {/* Monitoring */}
          <div className="mb-6">
            <label className="block mb-2 font-medium text-gray-900">Monitoring</label>
            <input
              type="text"
              placeholder="e.g. Blood Pressure Medicine"
              className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              value={monitoring}
              onChange={(e) => setMonitoring(e.target.value)}
            />
          </div>

          {/* Alert Preferences */}
          <div className="mb-6 bg-gray-50 rounded-xl p-4">
            <h3 className="font-medium text-gray-900 mb-4">Alert Preferences</h3>
            <div className="space-y-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={smsNotifications}
                  onChange={(e) => setSmsNotifications(e.target.checked)}
                  className="w-5 h-5 accent-blue-600 rounded"
                />
                <span className="text-gray-900">Send SMS Notifications</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={voiceCalls}
                  onChange={(e) => setVoiceCalls(e.target.checked)}
                  className="w-5 h-5 accent-blue-600 rounded"
                />
                <span className="text-gray-900">Enable Voice Calls for Emergencies</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={dailySummary}
                  onChange={(e) => setDailySummary(e.target.checked)}
                  className="w-5 h-5 accent-blue-600 rounded"
                />
                <span className="text-gray-900">Send Daily Health Summary</span>
              </label>
            </div>
          </div>

          {/* Priority Level */}
          <div className="mb-6">
            <label className="block mb-2 font-medium text-gray-900">Priority Level</label>
            <select
              className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 appearance-none"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'%3E%3Cpath d='M5 7.5L10 12.5L15 7.5' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 12px center'
              }}
              value={priorityLevel}
              onChange={(e) => setPriorityLevel(e.target.value)}
            >
              <option>Primary Contact (Called First)</option>
              <option>Secondary Contact</option>
              <option>Emergency Contact Only</option>
            </select>
          </div>

          {/* Notification Timing */}
          <div className="mb-6 bg-yellow-50 border-2 border-yellow-400 rounded-xl p-4">
            <div className="flex items-start gap-2 mb-4">
              <Clock className="w-5 h-5 text-yellow-700 flex-shrink-0 mt-0.5" />
              <h3 className="font-medium text-gray-900">Notification Timing</h3>
            </div>

            {/* SMS Notification Delay */}
            <div className="mb-4">
              <label className="block mb-2 text-sm font-medium text-gray-900">SMS Notification Delay</label>
              <select
                className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-yellow-500 text-gray-900 appearance-none"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'%3E%3Cpath d='M5 7.5L10 12.5L15 7.5' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center'
                }}
                value={smsDelay}
                onChange={(e) => setSmsDelay(e.target.value)}
              >
                <option>After 5 minutes</option>
                <option>After 10 minutes</option>
                <option>After 15 minutes (Recommended)</option>
                <option>After 20 minutes</option>
                <option>After 30 minutes</option>
              </select>
            </div>

            {/* Voice Call Delay */}
            <div className="mb-4">
              <label className="block mb-2 text-sm font-medium text-gray-900">Voice Call Delay (For Emergencies)</label>
              <select
                className="w-full px-4 py-3 bg-white border-2 border-orange-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 text-gray-900 appearance-none"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'%3E%3Cpath d='M5 7.5L10 12.5L15 7.5' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center'
                }}
                value={voiceDelay}
                onChange={(e) => setVoiceDelay(e.target.value)}
              >
                <option>After 15 minutes</option>
                <option>After 20 minutes</option>
                <option>After 30 minutes (Recommended)</option>
                <option>After 45 minutes</option>
                <option>After 1 hour</option>
              </select>
            </div>

            {/* Timing Note */}
            <div className="bg-yellow-100 border border-yellow-300 rounded-xl p-3">
              <p className="text-sm text-yellow-900">
                <span className="font-medium">Timing Note:</span> Delays give you time to mark the reminder as completed before notifying caregivers. This prevents unnecessary alerts.
              </p>
            </div>
          </div>

          {/* Blue Note */}
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p className="text-sm text-blue-900">
              <span className="font-medium">Note:</span> The caregiver will receive alerts based on their priority level and your selected preferences. Primary contacts are notified first in emergencies.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={onClose}
              className="py-3 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition-colors text-gray-900 font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="py-3 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors font-medium"
            >
              Save Caregiver
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}