import { Heart } from 'lucide-react';

interface SplashScreenProps {
  onContinue: () => void;
}

export function SplashScreen({ onContinue }: SplashScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 to-blue-600 relative overflow-hidden flex items-center justify-center">
      {/* Decorative circles */}
      <div className="absolute top-24 left-12 w-32 h-32 bg-cyan-300/40 rounded-full"></div>
      <div className="absolute top-1/3 left-48 w-40 h-40 bg-cyan-300/30 rounded-full"></div>
      <div className="absolute bottom-32 right-24 w-64 h-64 bg-blue-400/30 rounded-full"></div>

      <div className="text-center z-10 px-6">
        {/* Heart icon */}
        <div className="mb-8 inline-flex items-center justify-center w-36 h-36 bg-white rounded-full shadow-lg">
          <Heart className="w-20 h-20 text-cyan-400 fill-cyan-400" />
        </div>

        {/* Title in Hindi */}
        <h1 className="text-5xl mb-4 text-white font-bold">स्वास्थ्य साथी</h1>
        
        {/* Subtitle in English */}
        <h2 className="text-3xl text-white/90 mb-8">Health Companion</h2>

        {/* Tagline box */}
        <div className="bg-white/95 rounded-2xl px-8 py-4 inline-block mb-16">
          <p className="text-cyan-500 text-xl">Your Health, Our Priority</p>
        </div>

        {/* Loading dots */}
        <div className="flex justify-center gap-3 mb-20">
          <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
          <div className="w-3 h-3 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
          <div className="w-3 h-3 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
        </div>

        {/* Footer */}
        <div className="text-white/90 text-center">
          <p className="text-lg mb-1">Powered by Government of India</p>
          <p className="text-base">भारत सरकार द्वारा संचालित</p>
        </div>
      </div>

      {/* Auto-advance after 3 seconds */}
      <div className="absolute inset-0" onClick={onContinue}></div>
    </div>
  );
}
