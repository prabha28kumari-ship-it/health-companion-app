import { Shield, Info, Lock, Eye, ShieldCheck } from 'lucide-react';
import { useState } from 'react';

interface ConsentScreenProps {
  onContinue: () => void;
}

export function ConsentScreen({ onContinue }: ConsentScreenProps) {
  const [accepted, setAccepted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (accepted) {
      onContinue();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-cyan-500 rounded-full mb-6">
            <Shield className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl mb-2">सहमति आवश्यक</h1>
          <p className="text-cyan-600">Consent Required</p>
        </div>

        {/* Consent form */}
        <div className="bg-white rounded-3xl shadow-lg p-8">
          <form onSubmit={handleSubmit}>
            {/* Information points */}
            <div className="space-y-4 mb-6">
              <div className="bg-cyan-50 p-4 rounded-xl flex gap-3">
                <Info className="w-5 h-5 text-cyan-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-gray-800 mb-1">हम आपकी पहचान की पुष्टि के लिए आधार का उपयोग करेंगे</p>
                  <p className="text-cyan-600 text-sm">We will use Aadhaar for identity verification only</p>
                </div>
              </div>

              <div className="bg-cyan-50 p-4 rounded-xl flex gap-3">
                <Lock className="w-5 h-5 text-cyan-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-gray-800 mb-1">आपका आधार नंबर संग्रहीत नहीं किया जाएगा</p>
                  <p className="text-cyan-600 text-sm">Your Aadhaar number will not be stored</p>
                </div>
              </div>

              <div className="bg-cyan-50 p-4 rounded-xl flex gap-3">
                <Eye className="w-5 h-5 text-cyan-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-gray-800 mb-1">केवल सत्यापन के लिए उपयोग किया जाएगा</p>
                  <p className="text-cyan-600 text-sm">Used only for verification purposes</p>
                </div>
              </div>

              <div className="bg-cyan-50 p-4 rounded-xl flex gap-3">
                <ShieldCheck className="w-5 h-5 text-cyan-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-gray-800 mb-1">पूर्ण रूप से सुरक्षित और एन्क्रिप्टेड</p>
                  <p className="text-cyan-600 text-sm">Fully secure and encrypted</p>
                </div>
              </div>
            </div>

            {/* Consent checkbox */}
            <div className="bg-yellow-50 border-2 border-yellow-300 rounded-xl p-4 mb-6">
              <label className="flex gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={accepted}
                  onChange={(e) => setAccepted(e.target.checked)}
                  className="w-5 h-5 mt-0.5 accent-cyan-500 flex-shrink-0"
                />
                <div>
                  <p className="text-gray-800 mb-1">
                    मैं आधार-आधारित सत्यापन के लिए सहमत हूं और समझता हूं कि मेरा आधार नंबर संग्रहीत नहीं किया जाएगा
                  </p>
                  <p className="text-cyan-600 text-sm">
                    I consent to Aadhaar-based verification and understand that my Aadhaar number will not be stored
                  </p>
                </div>
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-cyan-400 hover:bg-cyan-500 text-white py-4 rounded-xl transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              disabled={!accepted}
            >
              स्वीकार करें और जारी रखें / Accept & Continue
            </button>
          </form>
        </div>

        {/* Footer note */}
        <p className="text-center mt-6 text-sm text-gray-600">
          यह केवल एक अवधारणा प्रवाह है - कोई वास्तविक आधार एकीकरण नहीं
          <br />
          <span className="text-cyan-600">This is a conceptual flow only - No real Aadhaar integration</span>
        </p>
      </div>
    </div>
  );
}
