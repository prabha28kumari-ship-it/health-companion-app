import { 
  ArrowLeft, 
  Phone, 
  Bell, 
  Globe, 
  HelpCircle, 
  Shield, 
  ChevronRight, 
  LogOut
} from 'lucide-react';
import { useState } from 'react';

interface SettingsScreenProps {
  onBack: () => void;
}

type SettingsView = 'settings' | 'change-number' | 'notifications' | 'language' | 'help';

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  const [currentView, setCurrentView] = useState<SettingsView>('settings');
  const [phoneNumber] = useState('+91 6677889999');
  const [newPhoneNumber, setNewPhoneNumber] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('hindi');
  
  // Settings states
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [medicationReminders, setMedicationReminders] = useState(true);
  const [appointmentReminders, setAppointmentReminders] = useState(true);
  const [healthTips, setHealthTips] = useState(true);

  const languages = [
    { value: 'hindi', label: 'हिंदी / Hindi', flag: '🇮🇳', speakers: '52+ करोड़ बोलने वाले / 520M+ speakers' },
    { value: 'marathi', label: 'मराठी / Marathi', flag: '🇮🇳', speakers: '8+ करोड़ बोलने वाले / 80M+ speakers' },
    { value: 'bengali', label: 'बांग्ला / Bengali', flag: '🇮🇳', speakers: '23+ करोड़ बोलने वाले / 230M+ speakers' },
    { value: 'english', label: 'English', flag: '🇬🇧', speakers: '125M+ speakers' }
  ];

  const handleLogout = () => {
    if (confirm('Are you sure you want to logout? / क्या आप लॉग आउट करना चाहते हैं?')) {
      alert('Logged out successfully');
    }
  };

  // Main Settings View
  if (currentView === 'settings') {
    return (
      <div className="min-h-screen bg-cyan-50 relative">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-6 py-6 text-white">
          <button onClick={onBack} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold mb-1">सेटिंग्स</h1>
          <p className="text-sm">Settings</p>
        </header>

        {/* Main Content */}
        <div className="px-5 py-6 pb-24">
          {/* Account Settings */}
          <h2 className="text-lg font-bold mb-4 text-cyan-600">खाता / Account</h2>

          {/* Change Mobile Number */}
          <button
            onClick={() => setCurrentView('change-number')}
            className="w-full bg-white rounded-2xl p-5 mb-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <Phone className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">मोबाइल नंबर बदलें</h3>
              <p className="text-sm text-cyan-600 mb-1">Change Mobile Number</p>
              <p className="text-sm text-gray-600">{phoneNumber}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Notifications */}
          <button
            onClick={() => setCurrentView('notifications')}
            className="w-full bg-white rounded-2xl p-5 mb-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <Bell className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">सूचनाएं</h3>
              <p className="text-sm text-cyan-600 mb-1">Notifications</p>
              <p className="text-sm text-gray-600">+91 चालू / Enabled</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Language */}
          <button
            onClick={() => setCurrentView('language')}
            className="w-full bg-white rounded-2xl p-5 mb-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <Globe className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">भाषा</h3>
              <p className="text-sm text-cyan-600 mb-1">Language</p>
              <p className="text-sm text-gray-600">+91 हिंदी / Hindi</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Help & Support */}
          <button
            onClick={() => setCurrentView('help')}
            className="w-full bg-white rounded-2xl p-5 mb-6 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <HelpCircle className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">सहायता और समर्थन</h3>
              <p className="text-sm text-cyan-600">Help & Support</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Security Information */}
          <div className="bg-cyan-50 border-2 border-cyan-400 rounded-2xl p-5 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-6 h-6 text-cyan-600" />
              <h3 className="font-bold text-gray-800">सुरक्षा जानकारी / Security Information</h3>
            </div>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>आपकी जानकारी सुरक्षित और एन्क्रिप्टेड है</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>Your information is secure and encrypted</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>हम आपका डेटा कभी साझा नहीं करते / We never share your data</span>
              </li>
            </ul>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full bg-white border-2 border-red-400 text-red-600 py-4 rounded-2xl hover:bg-red-50 transition-colors flex items-center justify-center gap-2 font-medium"
          >
            <LogOut className="w-5 h-5" />
            <span>लॉग आउट / Logout</span>
          </button>
        </div>

        {/* Floating Language Button */}
        <button 
          onClick={() => setCurrentView('language')}
          className="fixed bottom-6 right-6 bg-cyan-600 text-white p-4 rounded-full shadow-lg hover:bg-cyan-700 transition-colors z-50"
          aria-label="Change Language"
        >
          <Globe className="w-6 h-6" />
        </button>
      </div>
    );
  }

  // Change Mobile Number View
  if (currentView === 'change-number') {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">मोबाइल नंबर बदलें</h1>
          <p className="text-sm text-cyan-100">Change Mobile Number</p>
        </header>

        <div className="px-4 py-6">
          <div className="bg-white rounded-3xl p-6">
            <div className="mb-6">
              <label className="block text-sm text-gray-700 mb-2">नया मोबाइल नंबर / New Mobile Number</label>
              <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-2xl">
                <Phone className="w-4 h-4 text-gray-600" />
                <input
                  type="tel"
                  value={newPhoneNumber}
                  onChange={(e) => setNewPhoneNumber(e.target.value)}
                  placeholder="Enter new mobile number"
                  className="flex-1 bg-transparent outline-none"
                />
              </div>
            </div>

            <button className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white py-4 rounded-2xl hover:opacity-90 transition-opacity">
              OTP भेजें / Send OTP
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Notifications View
  if (currentView === 'notifications') {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">सूचनाएं</h1>
          <p className="text-sm text-cyan-100">Notifications</p>
        </header>

        <div className="px-4 py-6">
          <div className="bg-white rounded-3xl p-5 mb-6">
            <h3 className="font-medium mb-4">सूचनाएं सेटिंग्स / Notification Settings</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span>सभी सूचनाएं / All Notifications</span>
                <input type="checkbox" checked={notificationsEnabled} onChange={(e) => setNotificationsEnabled(e.target.checked)} className="w-5 h-5" />
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span>दवा अनुस्मारक / Medication Reminders</span>
                <input type="checkbox" checked={medicationReminders} onChange={(e) => setMedicationReminders(e.target.checked)} className="w-5 h-5" />
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <span>अपॉइंटमेंट / Appointments</span>
                <input type="checkbox" checked={appointmentReminders} onChange={(e) => setAppointmentReminders(e.target.checked)} className="w-5 h-5" />
              </div>
              
              <div className="flex items-center justify-between py-3">
                <span>स्वास्थ्य टिप्स / Health Tips</span>
                <input type="checkbox" checked={healthTips} onChange={(e) => setHealthTips(e.target.checked)} className="w-5 h-5" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Language View
  if (currentView === 'language') {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">भाषा चुनें</h1>
          <p className="text-sm text-cyan-100">Select Language</p>
        </header>

        <div className="px-4 py-6">
          <div className="space-y-3">
            {languages.map((lang) => (
              <button
                key={lang.value}
                onClick={() => setSelectedLanguage(lang.value)}
                className={`w-full bg-white rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow ${
                  selectedLanguage === lang.value ? 'border-2 border-cyan-500' : ''
                }`}
              >
                <div className="text-4xl">{lang.flag}</div>
                <div className="flex-1 text-left">
                  <h3 className="font-medium mb-1">{lang.label}</h3>
                  <p className="text-sm text-gray-600">{lang.speakers}</p>
                </div>
                {selectedLanguage === lang.value && (
                  <div className="w-5 h-5 bg-cyan-500 rounded-full" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Help View (placeholder)
  if (currentView === 'help') {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">सहायता और समर्थन</h1>
          <p className="text-sm text-cyan-100">Help & Support</p>
        </header>

        <div className="px-4 py-6">
          <div className="bg-white rounded-3xl p-6">
            <h3 className="font-medium mb-4">Help & Support</h3>
            <p className="text-gray-600">Contact support for assistance.</p>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
